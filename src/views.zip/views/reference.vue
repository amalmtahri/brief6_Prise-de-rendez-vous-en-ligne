<template>
  <reference/>
</template>

<script>
import reference from '@/components/reference.vue'

export default {
  name: 'Reference',
  components: {
    reference,
  }
}
</script>

<style>

</style>