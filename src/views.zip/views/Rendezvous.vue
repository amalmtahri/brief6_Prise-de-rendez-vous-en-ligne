<template>

       <rendezvous/>
  
</template>

<script>
import rendezvous from '@/components/Rendezvous.vue'
export default {
  name:'rendez',
   components: {
    rendezvous,
  }
}
</script>

<style>

</style>