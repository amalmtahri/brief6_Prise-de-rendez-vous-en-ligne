<template>
  
    <add/>
 
</template>

<script>
// @ is an alias to /src
import add from '@/components/add.vue'

export default {
  name: 'Add',
  components: {
    add,
  }
}
</script>
