<template>
  <inscription/>
</template>

<script>
import inscription from '@/components/register.vue'

export default {
  name: 'register',
  components: {
    inscription,
  }
}
</script>

<style>

</style>